﻿using System;
using System.Runtime.InteropServices;
using System.Data;
using System.Drawing;

namespace ConsoleApp1
{
    class Program
    {
        public static float[] GetDpi()
        {
            using (Graphics graphics = Graphics.FromHwnd(IntPtr.Zero))
            {
                float dpiX = graphics.DpiX;
                float dpiY = graphics.DpiY;
                float[] result = new float[] { dpiX = dpiX, dpiY = dpiY };
                return result;
            }
        }
        static void Main(string[] args)
        {

            //
            //var handle = System.Windows.Automation.Window.GetWindowByName("MSN | Outlook, Office, Skype, Bing, Breaking News, and Latest Videos - Internet Explorer");
            //var samll = System.Windows.Automation.Screen.GetImageBitmap(@"D:\temp\test.png");
            //var point = System.Windows.Automation.Screen.GetImageInScreenPosition(samll, 0.8);
            var point = System.Windows.Automation.Screen.ClickImageInWindow(@"D:\temp\test.jpg", "MSN | Outlook, Office, Skype, Bing, Breaking News, and Latest Videos - Internet Explorer",0.8);
            //System.Windows.Automation.Mouse.MoveAndClickLeftMouse(1746, 561);
            //System.Windows.Automation.Screen.TakeScreenshot();
            //foreach (var item in System.Windows.Forms.Screen.AllScreens)
            //{
            //    Console.WriteLine(item.Primary);
            //    Console.WriteLine(item.Bounds.Width);
            //    Console.WriteLine(item.Bounds.Height);
            //}
            Console.WriteLine(point.X);
            Console.WriteLine(point.Y);
            //System.Windows.Automation.Mouse.ClickLeftButton(point.X, point.Y);
            Console.ReadLine();
        }
    }
}
