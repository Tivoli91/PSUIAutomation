﻿using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.IO;
using AForge.Imaging;
using System.Windows.Forms;

namespace System.Windows.Automation
{


    public static class Screen
    {
        private static readonly int screen_width = Forms.Screen.PrimaryScreen.Bounds.Width;
        private static readonly int screen_height = Forms.Screen.PrimaryScreen.Bounds.Height;
        internal static class SafeNativeMethods
        {
            [DllImport("gdi32.dll")]
            public static extern IntPtr CreateDC(
                string lpszDriver, // driver name驱动名
                string lpszDevice, // device name设备名
                string lpszOutput, // not used; should be NULL
                IntPtr lpInitData // optional printer data
            );

            [DllImport("gdi32.dll")]
            public static extern IntPtr CreateCompatibleDC(IntPtr hdc);    // handle to DC

            [DllImport("gdi32.dll")]
            public static extern IntPtr CreateCompatibleBitmap(
                IntPtr hdc, // handle to DC
                int nWidth, // width of bitmap, in pixels
                int nHeight // height of bitmap, in pixels
            );

            [DllImport("gdi32.dll")]
            public static extern IntPtr SelectObject(
                IntPtr hdc, // handle to DC
                IntPtr hgdiobj // handle to object
            );

            [DllImport("gdi32.dll")]
            public static extern int DeleteDC(IntPtr hdc);   // handle to DC


            [DllImport("gdi32.dll")]
            public static extern IntPtr DeleteObject(IntPtr hObject);


            [DllImport("user32.dll")]
            public static extern bool PrintWindow(
                IntPtr hwnd, // Window to copy,Handle to the window that will be copied. 
                IntPtr hdcBlt, // HDC to print into,Handle to the device context. 
                UInt32 nFlags // Optional flags,Specifies the drawing options. It can be one of the following values. 
            );

            [DllImport("user32.dll")]
            public static extern IntPtr GetWindowDC(IntPtr hwnd);

            [DllImport("user32.dll")]
            public static extern IntPtr ReleaseDC(IntPtr hWnd, IntPtr hDC);
        }

        private static Bitmap GetWindowScreenshotBitmap(string process_name,string windowsTitle)
        {
            var uiwindow = UIWindow.GetUIWindow(process_name, 0, windowsTitle);
            Console.WriteLine(uiwindow.Current.NativeWindowHandle);
            // (IntPtr)uiwindow.Current.NativeWindowHandle
            // uiwindow
            var size = UIWindow.GetUISize(uiwindow); 
            Console.WriteLine(size.Width);
            Console.WriteLine(size.Height);
            Console.ReadLine();
            //hWnd可以是窗口、控件等的handle
            IntPtr hscrdc = SafeNativeMethods.GetWindowDC((IntPtr)uiwindow.Current.NativeWindowHandle);
            IntPtr hbitmap = SafeNativeMethods.CreateCompatibleBitmap(hscrdc, (int)size.Width, (int)size.Height);
            IntPtr hmemdc = SafeNativeMethods.CreateCompatibleDC(hscrdc);
            SafeNativeMethods.SelectObject(hmemdc, hbitmap);
            bool re = SafeNativeMethods.PrintWindow((IntPtr)uiwindow.Current.NativeWindowHandle, hmemdc, 0);
            Bitmap bmp = null;
            if (re)
            {
                bmp = Bitmap.FromHbitmap(hbitmap);
            }
            SafeNativeMethods.DeleteObject(hbitmap);
            SafeNativeMethods.DeleteDC(hmemdc);//删除用过的对象       
            SafeNativeMethods.ReleaseDC((IntPtr)uiwindow.Current.NativeWindowHandle, hscrdc);
            bmp.Save(@"d:\temp\main.png");
            return bmp;
        }

        public static Bitmap TakePrimaryScreenshot() {
            var bitmap = new System.Drawing.Bitmap(Forms.Screen.PrimaryScreen.Bounds.Width, Forms.Screen.PrimaryScreen.Bounds.Height, PixelFormat.Format32bppArgb);
            var graphic = Graphics.FromImage(bitmap);
            graphic.CopyFromScreen(0, 0, 0, 0, bitmap.Size, CopyPixelOperation.SourceCopy);


            bitmap.Save(@"D:\temp\primaryscrren.jpg");
            return bitmap;
        }

        public static void TakeWindowScreenshot(string process_name, string windowsTitle, string SaveFile)
        {
            GetWindowScreenshotBitmap(process_name, windowsTitle).Save(SaveFile);
        }

        public static Bitmap GetImageBitmap(string search_image) 
        {
            // without locking the image file
            var fs = new FileStream(search_image, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            var search_image_bitmap = (Bitmap)Bitmap.FromStream(fs);
            fs.Close(); fs.Dispose();
            return search_image_bitmap;
        }
        public static Rectangle SearchBitmap(Bitmap bigBmp, Bitmap smallBmp, double tolerance)
        {
            BitmapData smallData =
              smallBmp.LockBits(new Rectangle(0, 0, smallBmp.Width, smallBmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            BitmapData bigData =
              bigBmp.LockBits(new Rectangle(0, 0, bigBmp.Width, bigBmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);

            int smallStride = smallData.Stride;
            int bigStride = bigData.Stride;

            int bigWidth = bigBmp.Width;
            int bigHeight = bigBmp.Height - smallBmp.Height + 1;
            int smallWidth = smallBmp.Width * 3;
            int smallHeight = smallBmp.Height;

            Rectangle location = Rectangle.Empty;
            int margin = Convert.ToInt32(255.0 * tolerance);

            unsafe
            {
                byte* pSmall = (byte*)(void*)smallData.Scan0;
                byte* pBig = (byte*)(void*)bigData.Scan0;

                int smallOffset = smallStride - smallBmp.Width * 3;
                int bigOffset = bigStride - bigBmp.Width * 3;

                bool matchFound = true;

                for (int y = 0; y < bigHeight; y++)
                {
                    for (int x = 0; x < bigWidth; x++)
                    {
                        byte* pBigBackup = pBig;
                        byte* pSmallBackup = pSmall;

                        //Look for the small picture.
                        for (int i = 0; i < smallHeight; i++)
                        {
                            int j = 0;
                            matchFound = true;
                            for (j = 0; j < smallWidth; j++)
                            {
                                //With tolerance: pSmall value should be between margins.
                                int inf = pBig[0] - margin;
                                int sup = pBig[0] + margin;
                                if (sup < pSmall[0] || inf > pSmall[0])
                                {
                                    matchFound = false;
                                    break;
                                }

                                pBig++;
                                pSmall++;
                            }

                            if (!matchFound) break;

                            //We restore the pointers.
                            pSmall = pSmallBackup;
                            pBig = pBigBackup;

                            //Next rows of the small and big pictures.
                            pSmall += smallStride * (1 + i);
                            pBig += bigStride * (1 + i);
                        }

                        //If match found, we return.
                        if (matchFound)
                        {
                            location.X = x;
                            location.Y = y;
                            location.Width = smallBmp.Width;
                            location.Height = smallBmp.Height;
                            break;
                        }
                        //If no match found, we restore the pointers and continue.
                        else
                        {
                            pBig = pBigBackup;
                            pSmall = pSmallBackup;
                            pBig += 3;
                        }
                    }

                    if (matchFound) break;

                    pBig += bigOffset;
                }
            }

            bigBmp.UnlockBits(bigData);
            smallBmp.UnlockBits(smallData);

            return location;
        }

        public static void SearchImageInWindow(Bitmap bigBmp, Bitmap smallBmp, double tolerance) {
            Bitmap bitpix_format= new Bitmap(bigBmp.Width, bigBmp.Height, PixelFormat.Format24bppRgb);
            Bitmap smallpix_format = new Bitmap(smallBmp.Width, smallBmp.Height, PixelFormat.Format24bppRgb);
            ExhaustiveTemplateMatching tm = new ExhaustiveTemplateMatching(0.921f);
            TemplateMatch[] matchings = tm.ProcessImage(bitpix_format, smallpix_format);
            BitmapData data = bigBmp.LockBits(
                new Rectangle(0, 0, bigBmp.Width, bigBmp.Height),
                ImageLockMode.ReadWrite, bigBmp.PixelFormat);
            Console.WriteLine("going matchings");
            foreach (TemplateMatch m in matchings)
            {

                //Drawing.Rectangle(data, m.Rectangle, Color.White);

                MessageBox.Show(m.Rectangle.Location.ToString());
                // do something else with matching
            }
            Console.WriteLine("out matchings");
            bigBmp.UnlockBits(data);
        }

        public static Point GetImageInScreenPosition(string search_image,double tolerance)
        {
            return GetImageInScreenPosition(GetImageBitmap(search_image), tolerance);
        }

        public static Point GetImageInScreenPosition(Bitmap search_image_bitmap, double tolerance)
        {
            var window_bitmap = TakePrimaryScreenshot();

            var imagerect = SearchBitmap(window_bitmap, search_image_bitmap, tolerance);

            return new Point(imagerect.X, imagerect.Y);
        }

        public static Point ClickImageInWindow(string search_image,string windowsTitle, double tolerance) {
            Window.Activate(Window.GetWindowHandleByName(windowsTitle));

            var search_bitmap = GetImageBitmap(search_image);

            var position = GetImageInScreenPosition(search_bitmap,  tolerance);
            position.X += (int)Math.Round((double)search_bitmap.Width / 2);
            position.Y += (int)Math.Round((double)search_bitmap.Height / 2);
            Console.WriteLine("going SearchImageInWindow");
            //SearchImageInWindow(TakePrimaryScreenshot(), GetImageBitmap(search_image), tolerance);
            //Console.WriteLine("going SearchImageInWindow");
            return position;
        }
    }
}
