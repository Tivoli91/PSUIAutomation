﻿using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;

namespace System.Windows.Automation
{

    public static class Window
    {
        internal static class SafeNativeMethods
        {
            [return: MarshalAs(UnmanagedType.Bool)]
            [DllImport("user32.dll", SetLastError = true)]
            internal static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

            [return: MarshalAs(UnmanagedType.Bool)]
            [DllImport("user32.dll")]
            internal static extern bool SetForegroundWindow(IntPtr hWnd);

            [DllImport("user32.dll")]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern bool GetWindowPlacement(IntPtr hWnd, ref WINDOWPLACEMENT lpwndpl);

            [DllImport("user32.dll", SetLastError = true)]
            internal static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        }

        public struct WINDOWPLACEMENT
        {
            public int length;
            public int flags;
            public int showCmd;
            public Point ptMinPosition;
            public Point ptMaxPosition;
            public Rectangle rcNormalPosition;
            public Rectangle rcDevice;
        }

        public static void Activate(IntPtr hWnd)
        {
            if (GetWindowState(hWnd)==2)
            {
                SafeNativeMethods.ShowWindow(hWnd, 9); // try to restore minimized window
            }
            SafeNativeMethods.SetForegroundWindow(hWnd); // then active window

        }

        public static void Maximize(IntPtr hWnd)
        {
            SafeNativeMethods.ShowWindow(hWnd, 3); // try to Maximize window anyway
            SafeNativeMethods.SetForegroundWindow(hWnd); // then active window
        }

        public static int GetWindowState(IntPtr handle)
        {
            WINDOWPLACEMENT placement = new WINDOWPLACEMENT();
            placement.length = Marshal.SizeOf(placement);
            SafeNativeMethods.GetWindowPlacement(handle, ref placement);
            return placement.showCmd;
            // 1 normal 2 minimize 3 maxmize
        }

        public static IntPtr GetWindowHandleByName(string windowsTitle)
        {
            Process[] processes = Process.GetProcesses();
            foreach (var p in Process.GetProcesses())
            {
                if (p.MainWindowTitle.Equals(windowsTitle))
                {
                    return p.MainWindowHandle;
                }
            }
            return IntPtr.Zero;
        }
    }
}
