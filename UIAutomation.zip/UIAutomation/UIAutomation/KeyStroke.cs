﻿using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;

namespace System.Windows.Automation
{
    public class KeyStroke
    {
        private const uint WM_CHAR = 0x0102;
        private const uint WM_CLEAR = 0x00303;
        private const uint WM_COPY = 0x0301;
        private const uint WM_PASTE = 0x0302;
        private const uint WM_CUT = 0x0300;

        internal static class SafeNativeMethods
        {
            [return: MarshalAs(UnmanagedType.Bool)]
            [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
            internal static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

            [return: MarshalAs(UnmanagedType.SysUInt)]
            [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
            internal static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
        }

        public static void Send(IntPtr hWindow, string message)
        {
            for (int i = 0; i < message.Length; i++)
            {
                SafeNativeMethods.PostMessage(hWindow, WM_CHAR, (IntPtr)message[i], IntPtr.Zero);
            }
        }
        public static void SendWait(IntPtr hWindow, string message)
        {
            for (int i = 0; i < message.Length; i++)
            {
                SafeNativeMethods.SendMessage(hWindow, WM_CHAR, (IntPtr)message[i], IntPtr.Zero);
            }
        }

        private static uint GetClipboardActionType(String ActionType)
        {
            uint message = WM_COPY;
            switch (ActionType.ToUpper())
            {
                case "COPY":
                    message = WM_COPY;
                    break;
                case "PASTE":
                    message = WM_PASTE;
                    break;
                case "CUT":
                    message = WM_CUT;
                    break;
                case "CLEAR":
                    message = WM_CLEAR;
                    break;
            }
            return message;
        }

        public static void SendClipboard(IntPtr hWindow, String ActionType)
        {
            SafeNativeMethods.PostMessage(hWindow, GetClipboardActionType(ActionType), IntPtr.Zero, IntPtr.Zero);
        }
        public static void SendClipboardWait(IntPtr hWindow, String ActionType)
        {
            SafeNativeMethods.SendMessage(hWindow, GetClipboardActionType(ActionType), IntPtr.Zero, IntPtr.Zero);
        }
    }

}
