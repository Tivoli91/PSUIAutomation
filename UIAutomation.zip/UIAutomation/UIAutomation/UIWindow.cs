﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;

namespace System.Windows.Automation
{
    public class UIWindow
    {
        internal static class SafeNativeMethods
        {
            [DllImport("user32.dll", SetLastError = true)]
            internal static extern bool GetWindowRect(IntPtr hwnd, out RECT lpRect);
        }
        
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;        // x position of upper-left corner
            public int Top;         // y position of upper-left corner
            public int Right;       // x position of lower-right corner
            public int Bottom;      // y position of lower-right corner
        }
        public static AutomationElement GetUIWindow(string process_name,int process_id,string process_title) 
        {
            int pid= process_id;
            if (process_name!=null)
            {
                Process[] processes = Process.GetProcessesByName(process_name);
                if (processes.Length > 1)
                {
                    if (string.IsNullOrWhiteSpace(process_title))
                    {
                        throw new System.ArgumentNullException(string.Format("Thera are more than one \"{0}\" process, but process title has not been provided!", process_name));
                    }
                    else
                    {
                        foreach (var p in processes)
                        {
                            if (p.MainWindowTitle.Equals(process_title))
                            {
                                pid = p.Id;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    pid = processes[0].Id;
                }
            }

            try
            {
                return AutomationElement.RootElement.FindFirst(
                    TreeScope.Children,
                    new PropertyCondition(
                        AutomationElement.ProcessIdProperty,
                        pid
                    )
                );
            }
            catch (Exception e)
            {

                throw e;
            }
        }

        public struct Rect
        {
            public Double X;
            public Double Y;
            public Double Width;
            public Double Height;

        }
        public static Rect GetUISize(AutomationElement uiwindow)
        {
            try
            {
                Rect rect = new Rect();
                var window_rect = uiwindow.GetCurrentPropertyValue(AutomationElement.BoundingRectangleProperty);

                var window_rect_type = window_rect.GetType();
                rect.X = (Double)window_rect_type.GetProperty("X").GetValue(window_rect, null);
                rect.Y = (Double)window_rect_type.GetProperty("Y").GetValue(window_rect, null);
                rect.Width = (Double)window_rect_type.GetProperty("Width").GetValue(window_rect, null);
                rect.Height = (Double)window_rect_type.GetProperty("Height").GetValue(window_rect, null);
                return rect;
            }
            catch (Exception e)
            {

                throw e;
            }
        }

        public static RECT GetUISize(IntPtr handle) {
            RECT rct;
            SafeNativeMethods.GetWindowRect(handle,out rct);
            return rct;
        }
    }
}
