﻿using System;
using System.Runtime.InteropServices;
using System.Drawing;

namespace System.Windows.Automation
{

    public static class test
    {
        private const int WM_LBUTTONDOWN = 0x0201;
        private const int WM_LBUTTONUP = 0x0202;

        internal static class SafeNativeMethods
        {
            [return: MarshalAs(UnmanagedType.Bool)]
            [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
            internal static extern bool PostMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);
        }


        public static void SendLeftClick(IntPtr hWnd)
        {
            SafeNativeMethods.PostMessage(hWnd, WM_LBUTTONUP, 0, 0x1e20b71);
        }
    }
}