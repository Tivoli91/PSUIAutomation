﻿using System.Drawing;
using System.Runtime.InteropServices;

namespace System.Windows.Automation
{

    public static class Mouse
    {
        private const int WM_LBUTTONDOWN = 0x0201;
        private const int WM_LBUTTONUP = 0x0202;

        //0x0002 corresponds to a left-mouse-down move
        //0x0004 corresponds to a left-mouse-up move

        private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const uint MOUSEEVENTF_LEFTUP = 0x0004;
        private static Point p;

        internal static class SafeNativeMethods
        {
            [return: MarshalAs(UnmanagedType.Bool)]
            [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
            internal static extern bool PostMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

            [return: MarshalAs(UnmanagedType.SysUInt)]
            [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
            internal static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

            [DllImport("user32.dll", SetLastError = true)]
            internal static extern uint SendInput(uint nInputs, ref INPUT pInputs, int cbSize);

            [DllImport("user32.dll")]
            internal static extern bool ScreenToClient(IntPtr hWnd, ref Point lpPoint);

            [DllImport("user32.dll",CallingConvention = CallingConvention.StdCall)]
            internal static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);

            [DllImport("user32.dll")]
            internal static extern bool GetCursorPos(out Point lpPoint);

            [DllImport("user32.dll")]
            internal static extern bool SetCursorPos(int x,int y);

            [DllImport("user32.dll")]
            internal static extern IntPtr WindowFromPoint(System.Drawing.Point p);
        }


        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT
        {
            public int type;
            public MouseKeybdhardwareInputUnion mkhi;
        }
        [StructLayout(LayoutKind.Explicit)]
        public struct MouseKeybdhardwareInputUnion
        {
            [FieldOffset(0)]
            public MouseInputData mi;
        }

        public struct MouseInputData
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public MouseEventFlags dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }
        [Flags]
        public enum MouseEventFlags : uint
        {
            MOUSEEVENTF_MOVE = 0x0001,
            MOUSEEVENTF_LEFTDOWN = 0x0002,
            MOUSEEVENTF_LEFTUP = 0x0004,
            MOUSEEVENTF_ABSOLUTE = 0x8000
        }

        enum SystemMetric
        {
            SM_CXSCREEN = 0,
            SM_CYSCREEN = 1,
            SM_CXVIRTUALSCREEN = 78,
            SM_CYVIRTUALSCREEN =79,
        }

        [DllImport("user32.dll")]
        static extern int GetSystemMetrics(SystemMetric smIndex);

        private static int CalculateAbsoluteCoordinateX(int x)
        {
            return (x * 65536) / GetSystemMetrics(SystemMetric.SM_CXVIRTUALSCREEN);
        }

        private static int CalculateAbsoluteCoordinateY(int y)
        {
            return (y * 65536) / GetSystemMetrics(SystemMetric.SM_CYVIRTUALSCREEN);
        }

        public static Point GetCursorPosition() {
            SafeNativeMethods.GetCursorPos(out p);
            return p;
        }

        public static void SetCursorPosition(int x, int y)
        {
            SafeNativeMethods.SetCursorPos(x,y);
        }

        public static void ClickLeftButton(int x, int y) // not work when DPI not equals to 100%
        {
            INPUT mouseInput = new INPUT
            {
                type = 0
            };
            mouseInput.mkhi.mi.dx = CalculateAbsoluteCoordinateX(x);
            mouseInput.mkhi.mi.dy = CalculateAbsoluteCoordinateY(y);
            mouseInput.mkhi.mi.mouseData = 0;

            mouseInput.mkhi.mi.dwFlags = MouseEventFlags.MOUSEEVENTF_MOVE | MouseEventFlags.MOUSEEVENTF_ABSOLUTE;
            SafeNativeMethods.SendInput(1, ref mouseInput, Marshal.SizeOf(new INPUT()));

            mouseInput.mkhi.mi.dwFlags = MouseEventFlags.MOUSEEVENTF_LEFTDOWN;
            SafeNativeMethods.SendInput(1, ref mouseInput, Marshal.SizeOf(new INPUT()));

            mouseInput.mkhi.mi.dwFlags = MouseEventFlags.MOUSEEVENTF_LEFTUP;
            SafeNativeMethods.SendInput(1, ref mouseInput, Marshal.SizeOf(new INPUT()));
        }

        public static void MoveAndClickLeftMouse(int x, int y) {
            SetCursorPosition(x,y);
            SafeNativeMethods.mouse_event(MOUSEEVENTF_LEFTDOWN| MOUSEEVENTF_LEFTUP, 0, 0, 0, 0); 
             
        }

        public static void SendLeftClick(IntPtr hWnd, int x, int y)
        {
            //Point p = new Point(x, y);
            //SafeNativeMethods.ScreenToClient(hWnd, ref p);
            //Console.WriteLine(p.Y);
            //Console.WriteLine(p.X);
            //int coordinates = (short)(p.Y << 16) | (short)(p.X & 0xFFFF); 

            int coordinates = y << 16 | x & 0xFFFF;

            SafeNativeMethods.PostMessage(hWnd, WM_LBUTTONDOWN, 1, coordinates);
            SafeNativeMethods.PostMessage(hWnd, WM_LBUTTONUP, 0, coordinates);
        }



        const int WM_COMMAND = 0x0111;
        const int BN_CLICKED = 0;
        [DllImport("user32.dll")]
        static extern IntPtr GetDlgItem(IntPtr hWnd, int nIDDlgItem);
        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, IntPtr lParam);

        public static void TestClick(IntPtr handle, int ButtonId)
        {
            IntPtr hWndButton = GetDlgItem(handle, ButtonId);
            Console.WriteLine(hWndButton);
            int wParam = (BN_CLICKED << 16) | (ButtonId & 0xffff);
            SendMessage(handle, WM_COMMAND, wParam, hWndButton);
        }

        public static IntPtr GetPointHandle(int x,int y) {
            return SafeNativeMethods.WindowFromPoint(new Point(x,y));
        }
    }
}
