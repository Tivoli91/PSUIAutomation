﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Drawing;

namespace System.Windows.Automation
{
    public static class Monitor
    {
        internal static class SafeNativeMethods
        {
            /// <summary>
            /// Enumerates through the display monitors.
            /// </summary>
            /// <param name="hdc">A handle to a display device context that defines the visible region of interest.</param>
            /// <param name="lprcClip">A pointer to a RECT structure that specifies a clipping rectangle.</param>
            /// <param name="lpfnEnum">A pointer to a MonitorEnumProc application-defined callback function.</param>
            /// <param name="dwData">Application-defined data that EnumDisplayMonitors passes directly to the MonitorEnumProc function.</param>
            /// <returns></returns>
            [DllImport("user32.dll")]
            internal static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr lprcClip, MonitorEnumDelegate lpfnEnum, IntPtr dwData);

            /// <summary>
            /// Gets the monitor information.
            /// </summary>
            /// <param name="hmon">A handle to the display monitor of interest.</param>
            /// <param name="mi">A pointer to a MONITORINFO instance created by this method.</param>
            /// <returns></returns>
            [DllImport("user32.dll")]
            internal static extern bool GetMonitorInfo(IntPtr hmon, ref MONITORINFOEX mi);

            [DllImport("user32.dll")]
            internal static extern int EnumDisplaySettings(string lpszDeviceName, int iModeNum, ref DEVMODE lpDevMode);
        }

        /// <summary>
        /// Rectangle
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        /// <summary>
        /// Monitor information.
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct MONITORINFOEX
        {
            public uint size;
            public RECT monitor;
            public RECT work;
            public uint flags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string DeviceName;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DEVMODE
        {
            private const int CCHDEVICENAME = 0x20;
            private const int CCHFORMNAME = 0x20;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 0x20)]
            public string dmDeviceName;
            public short dmSpecVersion;
            public short dmDriverVersion;
            public uint dmSize;
            public short dmDriverExtra;
            public int dmFields;
            public int dmPositionX;
            public int dmPositionY;
            public int dmDisplayFixedOutput;
            public short dmColor;
            public short dmDuplex;
            public short dmYResolution;
            public short dmTTOption;
            public short dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 0x20)]
            public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel;
            public int dmPelsWidth;
            public int dmPelsHeight;
            public int dmDisplayFlags;
            public int dmDisplayFrequency;
            public int dmICMMethod;
            public int dmICMIntent;
            public int dmMediaType;
            public int dmDitherType;
            public int dmReserved1;
            public int dmReserved2;
            public int dmPanningWidth;
            public int dmPanningHeight;
        }

        /// <summary>
        /// Monitor Enum Delegate
        /// </summary>
        /// <param name="hMonitor">A handle to the display monitor.</param>
        /// <param name="hdcMonitor">A handle to a device context.</param>
        /// <param name="lprcMonitor">A pointer to a RECT structure.</param>
        /// <param name="dwData">Application-defined data that EnumDisplayMonitors passes directly to the enumeration function.</param>
        /// <returns></returns>
        public delegate bool MonitorEnumDelegate(IntPtr hMonitor, IntPtr hdcMonitor,ref RECT lprcMonitor, IntPtr dwData);

        /// <summary>
        /// Monitor information with handle interface.
        /// </summary>
        public interface IMonitorInfoWithHandle
        {
            bool IsPrimary { get; }
            IntPtr MonitorHandle { get; }
            MONITORINFOEX MonitorInfoEX { get; }
            double Scale { get;  }
        }

        /// <summary>
        /// Monitor information with handle.
        /// </summary>
        public class MonitorInfoWithHandle : IMonitorInfoWithHandle
        {
            public bool IsPrimary { get; private set; }

            /// <summary>
            /// Gets the monitor handle.
            /// </summary>
            /// <value>
            /// The monitor handle.
            /// </value>
            public IntPtr MonitorHandle { get; private set; }

            /// <summary>
            /// Gets the monitor information.
            /// </summary>
            /// <value>
            /// The monitor information.
            /// </value>
            public MONITORINFOEX MonitorInfoEX { get; private set; }

            /// <summary>
            /// Gets the monitor DPI scale.
            /// </summary>
            /// <value>
            /// The monitor DPI scale.
            /// </value>
            public double Scale { get; private set; }


            /// <summary>
            /// Initializes a new instance of the <see cref="MonitorInfoWithHandle"/> class.
            /// </summary>
            /// <param name="monitorHandle">The monitor handle.</param>
            /// <param name="monitorInfo">The monitor information.</param>
            public MonitorInfoWithHandle(IntPtr monitorHandle, MONITORINFOEX monitorInfoEX, double scale, bool isprimary)
            {
                IsPrimary = isprimary;
                MonitorHandle = monitorHandle;
                MonitorInfoEX = monitorInfoEX;
                Scale = scale;
            }
        }

        private static IList<MonitorInfoWithHandle> _monitorInfos;



        /// <summary>
        /// Monitor Enum Delegate
        /// </summary>
        /// <param name="hMonitor">A handle to the display monitor.</param>
        /// <param name="hdcMonitor">A handle to a device context.</param>
        /// <param name="lprcMonitor">A pointer to a RECT structure.</param>
        /// <param name="dwData">Application-defined data that EnumDisplayMonitors passes directly to the enumeration function.</param>
        /// <returns></returns>
        private static bool MonitorEnum(IntPtr hMonitor, IntPtr hdcMonitor, ref RECT lprcMonitor, IntPtr dwData)
        {
            bool isprimary = false;


            var mi = new MONITORINFOEX();
            mi.size = (uint)Marshal.SizeOf(mi);
            SafeNativeMethods.GetMonitorInfo(hMonitor, ref mi);

            // try to get phyisc value and then count Scaling

            DEVMODE this_monitor_mode = GetDisplaySettings(mi.DeviceName);

            //Console.WriteLine("---------------------"+ mi.DeviceName + "---------------------");
            //Console.WriteLine("this_monitor_mode.dmPelsWidth " + this_monitor_mode.dmPelsWidth);
            //Console.WriteLine("mi.monitor.right " + mi.monitor.right);
            //Console.WriteLine("mi.monitor.left " + mi.monitor.left);
            //
            //Console.WriteLine("this_monitor_mode.dmPelsHeight " + this_monitor_mode.dmPelsHeight);
            //Console.WriteLine("mi.monitor.bottom " + mi.monitor.bottom);
            //Console.WriteLine("mi.monitor.top " + mi.monitor.top);

            double horzScale = (double)this_monitor_mode.dmPelsWidth / (double)(mi.monitor.right - mi.monitor.left);
            
            Console.WriteLine(string.Format("{0}/{1}", (double)this_monitor_mode.dmPelsWidth, (double)(mi.monitor.right - mi.monitor.left)));
            
            double vertScale = (double)this_monitor_mode.dmPelsHeight / (double)(mi.monitor.bottom - mi.monitor.top);

            Console.WriteLine(string.Format("{0}/{1}", (double)this_monitor_mode.dmPelsHeight, (double)(mi.monitor.bottom - mi.monitor.top)));

            Console.WriteLine(vertScale + "---"+horzScale);
            Diagnostics.Debug.Assert(horzScale == vertScale,"the x/y scale not equals");

            if (mi.monitor.left == 0)
            {
                isprimary = true;
            }

            _monitorInfos.Add(new MonitorInfoWithHandle(hMonitor, mi, vertScale, isprimary));
            return true;
        }

        /// <summary>
        /// Gets the monitors.
        /// </summary>
        /// <returns></returns>
        public static MonitorInfoWithHandle[] GetMonitors()
        {
            // New List
            _monitorInfos = new List<MonitorInfoWithHandle>();

            // Enumerate monitors, for each enum, run MonitorEnum yo get monitor info
            SafeNativeMethods.EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, MonitorEnum, IntPtr.Zero);

            // Return list
            return _monitorInfos.ToArray();
        }

        public static DEVMODE GetDisplaySettings(string dvname) 
        {
            const int ENUM_CURRENT_SETTINGS = -1;
            const int ENUM_REGISTRY_SETTINGS = -2;

            DEVMODE mode = new DEVMODE();
            mode.dmSize = (uint)Marshal.SizeOf(mode);
            mode.dmDriverExtra = 0;
            SafeNativeMethods.EnumDisplaySettings(dvname, ENUM_CURRENT_SETTINGS,ref mode);
            return mode;
        }
    }
}
