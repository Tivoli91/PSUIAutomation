﻿using System;
using System.Drawing;

namespace TempTest
{
    public class TestDLL
    {
        public static void Test() {
            // False 2624 278
            Point p = new Point(2624,278);
            System.Windows.Automation.Screen.ConvertPointInScreenToPointInWindow(p, (IntPtr)133004);
            Console.WriteLine(p.X);
            Console.WriteLine(p.Y);
            Console.ReadLine();
        }
    }
}
